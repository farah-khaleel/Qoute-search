# Quote Search Filter

This is a simple JavaScript web app that fetches quotes from the Dummy JSON API and allows the user to filter them by typing a substring.

## Features

- Fetches quote data from https://dummyjson.com/quotes.
- Displays quotes in a list.
- Filters quotes live as the user types.
- Shows an error message if the API call fails.

## How to Run

1. Open `index.html` in any browser.
2. Start typing in the input field to filter quotes.

## Author

Prepared for task submission.
